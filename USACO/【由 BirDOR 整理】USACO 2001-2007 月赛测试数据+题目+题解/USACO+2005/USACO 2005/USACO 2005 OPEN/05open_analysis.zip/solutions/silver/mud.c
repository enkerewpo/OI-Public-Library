/*
PROB: mud
LANG: C++
*/
#include <stdio.h>
#include <vector>
#include <algorithm>
using namespace std;

int main( void )
{
    FILE *input = fopen( "mud.in", "r" );
    FILE *output = fopen( "mud.out", "w" );
    int N, L;
    vector< pair<int, int> > pools;
    fscanf( input, "%d%d", &N, &L );
    pools.resize( N );
    for (int i = 0; i < N; i++)
	fscanf( input, "%d%d", &(pools[i].first), &(pools[i].second) );
    sort( pools.begin(), pools.end() );
    unsigned int used = 0;
    unsigned int p = 0;
    while (p < N) {
	unsigned int start = pools[p].first, end = pools[p].second;
	unsigned int nplanks = 1 + (end - 1 - start) / L;
	used += nplanks;
	unsigned int plend = start + nplanks * L;
	while (p < N && pools[p].second <= plend)
	    p++;
	if (p < N)
	    pools[p].first >?= plend;
    }
    fprintf( output, "%u\n", used );
    
    return 0;
}
