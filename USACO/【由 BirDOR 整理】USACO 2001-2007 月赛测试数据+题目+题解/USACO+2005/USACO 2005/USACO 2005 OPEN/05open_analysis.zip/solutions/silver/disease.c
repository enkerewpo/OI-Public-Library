/*
TASK: disease
LANG: C++
*/
#include <stdio.h>

const int MAXN = 10000;
int N, D, K;
int cows[MAXN];

int main( void )
{
    FILE *input = fopen( "disease.in", "r" );
    FILE *output = fopen( "disease.out", "w" );
    fscanf( input, "%d%d%d", &N, &D, &K );
    for (int i = 0; i < N; i++) {
	int count;
	fscanf( input, "%d", &count );
	for (int j = 0; j < count; j++) {
	    int d;
	    fscanf( input, "%d", &d );
	    cows[i] |= 1 << (d-1);
	}
    }
    int best = 0;
    for (int m = 0; m < (1 << D); m++) { // Allow diseases in m.
	int count = 0;
	for (int i = 0; i < D; i++)
	    count += (m >> i) & 1;
	if (count > K)
	    continue;
	int ok = 0;
	for (int i = 0; i < N; i++)
	    ok += ((cows[i] & ~m) == 0);
	best >?= ok;
    }
    fprintf( output, "%d\n", best );
    
    return 0;
}
