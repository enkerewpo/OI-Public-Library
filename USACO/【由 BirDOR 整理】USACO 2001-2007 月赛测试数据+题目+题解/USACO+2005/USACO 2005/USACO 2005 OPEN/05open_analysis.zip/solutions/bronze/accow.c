
/*
LANG: C
TASK: accow
*/
#include <stdio.h>

int elev[200][200];

main () {
    FILE *fin = fopen ("accow.in", "r");
    FILE *fout = fopen ("accow.out", "w");
    int r, c, i, j, nsafe=0, elevok, dx, dy;

    fscanf (fin, "%d %d", &r, &c);
    for (i = 0; i < r; i++) 
	for (j = 0; j < c; j++) 
	    fscanf (fin, "%d", &elev[i][j]);
    for (i = 1; i < r-1; i++) 
	for (j = 1; j < c-1; j++) {
	    elevok = 0;
	    for (dx = -1; dx <= 1; dx++) {
	        for (dy = -1; dy <= 1; dy++) {
		    if (dx==0 && dy==0) continue;
		    if (elev[i][j] > elev[i+dx][j+dy]) goto LOOPEND;
		}
	    }
	    nsafe++;
    LOOPEND:;
	}
    fprintf(fout, "%d\n", nsafe);
    exit (0);
}
