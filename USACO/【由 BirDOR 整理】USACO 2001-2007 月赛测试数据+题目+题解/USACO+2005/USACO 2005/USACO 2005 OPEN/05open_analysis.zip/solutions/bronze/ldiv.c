/*
LANG: C
TASK: ldiv
*/
#include <stdio.h>

main () {
    FILE *fin = fopen("ldiv.in", "r");
    FILE *fout = fopen("ldiv.out", "w");
    int a, b, q, i;
    fscanf (fin, "%d %d", &a, &b);
    q = a/b;
    fprintf(fout, "%d.", q);
    a -= q*b;
    for (i = 0; i < 35; i++) {
        a *= 10;
        q = a/b;
        fprintf(fout, "%d", q);
        a -= q*b;
    }
    fprintf(fout, "\n");
    exit (0);
}
