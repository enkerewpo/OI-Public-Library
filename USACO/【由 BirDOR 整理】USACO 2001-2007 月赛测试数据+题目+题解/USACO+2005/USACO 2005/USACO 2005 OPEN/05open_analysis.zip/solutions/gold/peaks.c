/*
TASK: peaks
LANG: C++
*/
using namespace std;

#include <vector>
#include <iostream>
#include <fstream>

int N,K,sol;
vector<int> h;

int main () {

  ifstream in ("peaks.in");
  in >> N >> K;
  h=vector<int>(N);
  for (int n=0; n<N; n++) in >> h[n];
  in.close();
  
  sol=0;
  
  while (1) {
    int start=0, onlyup=1, cnt=0;
    int beststart=-1, bestend=-1, bestnewh=-1, bestvolume=INT_MAX;
    
    for (int end=0; end<N; end++) {
      if (end==N-1 || (h[end+1]>h[end] && !onlyup)) {
	int volume=0, newh=0;
	if (start!=0) newh>?=h[start-1];
	if (end!=N-1) newh>?=h[end];
	
	for(int i=start; i<=end; i++) volume += max(h[i]-newh, 0);
	if (volume<bestvolume) {
	  bestvolume=volume;
	  beststart=start;
	  bestend=end;
	  bestnewh=newh;
	}
	
	cnt++;
	start=end+1;
	onlyup=1;
      }
      if (h[end+1]<h[end]) onlyup=0;
    }

    if (cnt<=K) break;
    
    sol += bestvolume;
    for (int i=beststart; i<=bestend; i++) h[i] <?= bestnewh;
  }

  ofstream out("peaks.out");
  out << sol << endl;
  out.close();
  return 0;
}
