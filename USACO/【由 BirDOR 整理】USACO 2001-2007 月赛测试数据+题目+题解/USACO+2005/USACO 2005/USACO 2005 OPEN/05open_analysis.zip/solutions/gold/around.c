/*
PROG: around
LANG: C++
*/

#include <iostream>
#include <fstream>
#include <list>
#include <set>
using namespace std;

ifstream fin ("around.in");
ofstream fout ("around.out");

int n, m;
int l[5001];
list<int> e[5001];
set<int> v[5001];
list<pair<pair<int, int>, int> > q;

int main()
{
    fin >> n >> m;
    for (int i = 1; i <= n; ++i) fin >> l[i];
    while (m--)
    {
	int i, j; fin >> i >> j;
	e[i].push_back(j); e[j].push_back(i);
    }
    q.push_back(make_pair(make_pair(1, l[1]), 0));
    v[1].insert(l[1]);
    while (!q.empty())
    {
	int i = q.front().first.first, x = q.front().first.second,
	    t = q.front().second + 1;
	q.pop_front();
	for (list<int>::iterator j = e[i].begin(); j != e[i].end(); ++j)
	{
	    int d = l[*j] - l[i];
	    if (d > 180) d -= 360; else if (d < -180) d += 360;
	    if (v[*j].find(x + d) == v[*j].end())
	    {
		if (*j == 1)
		{ fout << t << endl; return 0; }
		q.push_back(make_pair(make_pair(*j, x+d), t));
		v[*j].insert(x + d);
	    }
	}
    }
    fout << -1 << endl;
    return 0;
}
